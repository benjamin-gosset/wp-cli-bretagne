<?php
/**
 * Plugin Name: Atelier Incident
 * Description: Plugin volontairement défectueux pour l'atelier WP-CLI.
 * Version: 1.0.0
 */
if ( get_option( 'atelier_incident_enabled', '0' ) === '1' ) {
    throw new RuntimeException('Incident WP-CLI : le plugin Atelier Incident provoque volontairement une erreur.');
}
